^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package universal_robot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.5 (2019-04-05)
------------------
* Update maintainer listing: add Miguel (`#410 <https://github.com/ros-industrial/universal_robot/issues/410>`_)
* Add new metapackage, first step to rename the repo (`#409 <https://github.com/ros-industrial/universal_robot/issues/409>`_)
* UR-E Series (`#380 <https://github.com/ros-industrial/universal_robot/issues/380>`_)
* Update maintainer and author information.
* Contributors: Dave Niewinski, Nadia Hammoudeh García, gavanderhoorn

1.2.1 (2018-01-06)
------------------

1.2.0 (2017-08-04)
------------------

1.1.9 (2017-01-02)
------------------
* No changes.

1.1.8 (2016-12-30)
------------------
* all: update maintainers.
* Contributors: gavanderhoorn

1.1.7 (2016-12-29)
------------------
* No changes.

1.1.6 (2016-04-01)
------------------
* add moveit_config for ur3
* Contributors: ipa-fxm

1.0.2 (2014-03-31)
------------------
* Merge branch 'hydro-devel' of github.com:ros-industrial/universal_robot into hydro
* added missing dependency
* Contributors: Florian Weisshardt, ipa-fxm

1.0.1 (2014-03-31)
------------------

* Added all packages in dependency list of metapackage.
* Updated to catkin.  ur_driver's files were added to nested Python directory for including in other packages.
* Contributors: IPR-SR2, Kelsey
